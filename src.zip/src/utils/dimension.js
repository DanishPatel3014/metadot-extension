const dimension = {
  body: {
    _Width: 357, // in pixels
  },
  button: {
    _width: '50%', // in %
    _height: '50px', // in %
  },
};

export default dimension;
