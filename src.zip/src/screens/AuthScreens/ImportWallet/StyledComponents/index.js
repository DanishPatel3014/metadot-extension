import styled from 'styled-components';
import { colors, fonts } from '../../../../utils';

const { primaryTextColor, darkBgColor } = colors;
const { subHeadingFontSize } = fonts;

export const OptionDiv = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin-top: 0;
`;

export const Option = styled.p`
  width: 133px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: ${(props) => (props.selected ? 'rgba(33, 154, 154, 0.3);' : '#212121')};
  margin-right: 20px;
  font-weight: 500;
  font-size: ${subHeadingFontSize};
  line-height: 16px;
  letter-spacing: 0.02em;
  color: ${primaryTextColor};
  opacity: 0.8;
  border-radius: 20px;
  font-size: 0.8rem;
  cursor: pointer;
`;

export const UploadFileDiv = styled.div`
  float: left;
  margin-top: 30px;
  margin-left: 0.6rem;
`;

export const UploadFile = styled.label`
  background-color: ${darkBgColor};
  color: ${primaryTextColor};
  padding: 0.6rem 1rem;
  width: 140px;
  height: 30px;
  font-weight: 500;
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 0.02em;
  border-radius: 8px;
  border: 0.5px solid rgba(250, 250, 250, 0.5);
  display: flex;
  justify-content: flex-start;
  align-items: center;
  cursor: pointer;
`;

export const FileChosen = styled.div`
    margin-top: 1rem;
    margin-left: 0.1rem;
    font-size: 14px;
    line-height: 16px;
    letter-spacing: 0.02em;
    color: rgba(166, 68, 82, 0.8);
    text-align: left;
`;
